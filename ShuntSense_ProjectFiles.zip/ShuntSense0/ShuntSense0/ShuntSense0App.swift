//
//  ShuntSense0App.swift
//  ShuntSense0
//
//  Created by Bhavna Malladi on 2/11/25.
//

import SwiftUI
import SwiftData

@main
struct ShuntSense0App: App {
    
    
    var sharedModelContainer: ModelContainer = {
        let schema = Schema([
            Item.self,
        ])
        let modelConfiguration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: false)

        do {
            return try ModelContainer(for: schema, configurations: [modelConfiguration])
        } catch {
            fatalError("Could not create ModelContainer: \(error)")
        }
    }()

    var body: some Scene {
        WindowGroup {
            ContentView() // Start with  Screen
            //    .modelContainer(for: User.self) // Attach SwiftData Database
        }
    }
    
    
   
    
}
