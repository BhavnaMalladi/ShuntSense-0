////
////  UserModel.swift
////  ShuntSense0
////
////  Created by Bhavna Malladi on 2/18/25.
////
//
//import SwiftData
//import Foundation
//
//@Model
//class User {
//    var id: UUID = UUID() // Unique user ID
//    var fullName: String?
//    var dateOfBirth: Date
//    var emailOrPhone: String
//    var password: String
//    
//    init(fullName: String?, dateOfBirth: Date, emailOrPhone: String, password: String) {
//        self.fullName = fullName
//        self.dateOfBirth = dateOfBirth
//        self.emailOrPhone = emailOrPhone
//        self.password = password
//    }
//}
