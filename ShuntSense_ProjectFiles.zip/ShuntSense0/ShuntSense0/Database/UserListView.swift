////
////  UserListView.swift
////  ShuntSense0
////
////  Created by Bhavna Malladi on 3/20/25.
////
//
//
////
////  UserListView.swift
////  ShuntSense0
////
////  Created by Bhavna Malladi on 2/18/25.
////
//
//import SwiftUI
//import SwiftData
//
//struct UserListView: View {
//    @Environment(\.modelContext) private var modelContext
//    @State private var users: [User] = []
//    
//    var body: some View {
//        List(users, id: \.id) { user in
//            VStack(alignment: .leading) {
//                Text("Email/Phone: \(user.emailOrPhone)")
//                    .font(.headline)
//                if let fullName = user.fullName, !fullName.isEmpty {
//                    Text("Name: \(fullName)")
//                        .font(.subheadline)
//                }
//                Text("DOB: \(user.dateOfBirth, formatter: dateFormatter)")
//                    .font(.caption)
//            }
//        }
//        .onAppear {
//            loadUsers()
//        }
//    }
//    
//    private func loadUsers() {
//        do {
//            users = try modelContext.fetch(FetchDescriptor<User>())
//            print("Loaded users: \(users)") // Print user data to the console
//        } catch {
//            print("Error fetching users: \(error)")
//        }
//    }
//}
//
//private let dateFormatter: DateFormatter = {
//    let formatter = DateFormatter()
//    formatter.dateStyle = .medium
//    return formatter
//}()
//
//struct UserListView_Previews: PreviewProvider {
//    static var previews: some View {
//        let container = try! ModelContainer(for: User.self)
//        // Insert a sample user for testing purposes
//        container.mainContext.insert(
//            User(
//                fullName: "John Doe",
//                dateOfBirth: Date(),
//                emailOrPhone: "john@example.com",
//                password: "Password123!"
//            )
//        )
//        return UserListView()
//            .environment(\.modelContext, container.mainContext)
//    }
//}
