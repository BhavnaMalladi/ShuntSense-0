//
//  ShuntSense0Tests.swift
//  ShuntSense0Tests
//
//  Created by Bhavna Malladi on 2/11/25.
//

import Testing
@testable import ShuntSense0

struct ShuntSense0Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
